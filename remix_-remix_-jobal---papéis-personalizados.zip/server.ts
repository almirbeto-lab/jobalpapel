import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini Client safely
// Check if the key exists, but do not crash on load. Throw error on invocation.
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not defined in environment variables.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// API: Healthcheck
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// API: Assistant for Custom Orders Spec Generation and Quote Recommendation
app.post("/api/gemini/analyze-request", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "O texto do pedido é obrigatório." });
    }

    const ai = getGeminiClient();

    const systemInstruction = `Você é o Engenheiro de Produção e Analista Comercial Sênior de uma fábrica de papel personalizado (guardanapos, toalhas de papel interfolhas e sachês de guardanapo/açúcar/adoçante/lenço umedecido).
Sua tarefa é analisar o pedido informal ou rascunho de solicitação de um cliente fornecido pelo usuário e gerar as especificações técnicas ideais do produto, custos estimados de fabricação, preço de venda recomendado por milhar, custo de gravação do clichê (matriz de impressão), horas estimadas de produção e uma análise de viabilidade logística de prazo.

Regras de Negócio da Fábrica:
1. Categorias de Produtos e Limitações:
   - "guardanapo": Tamanhos (20x20cm, 30x30cm, 33x33cm, 40x40cm). Folhas: "folha_dupla" ou "folha_simples". Dobras: "1/4" ou "1/8".
   - "toalha": Tamanhos (20x21cm, 22x21cm, Bobina). Folhas: "folha_simples" ou "folha_dupla". Dobras: "interfolhado" (2 ou 3 dobras) ou "rolo".
   - "sache": Tamanhos (5x7cm para açúcar/adoçante em pó, 6x8cm para lenço umedecido). Folhas: "folha_simples" (para lenços). Dobras: "sache".
2. Custos Base Estimados (por milhar / 1000 unidades):
   - Guardanapo Folha Simples: R$ 15,00 a R$ 25,00 dependendo do tamanho.
   - Guardanapo Folha Dupla: R$ 35,00 a R$ 60,00.
   - Toalha de papel interfolha: R$ 22,00 a R$ 35,00.
   - Sachê (açúcar/adoçante): R$ 18,00 a R$ 28,00. Sachê Lenço Umedecido: R$ 120,00 a R$ 180,00.
3. Gravação de Clichê (Chapa de Borracha/Fotopolímero para Impressão flexográfica):
   - R$ 150,00 por cor de impressão. Se o cliente pedir 2 cores, R$ 300,00. Cores especiais (ouro, prata) têm acréscimo de R$ 50,00 por cor.
4. Preço de Venda Recomendado:
   - Geralmente calculamos com margem de 40% a 60% sobre o custo de produção, mais o custo do clichê cobrado separadamente do cliente na primeira compra.
5. Tempo de Setup de Máquina e Produção:
   - Setup inicial de impressão: 1 hora por cor de clichê.
   - Velocidade média da máquina: Guardanapo (800 unidades/minuto), Toalha (500 u/min), Sachê (300 u/min).
   - Tempo de gravação de clichê terceirizado: 3 dias úteis.

Responda rigorosamente no formato JSON de acordo com o esquema solicitado. Escreva as descrições e explicações em português brasileiro.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Analise esta solicitação do cliente e retorne os parâmetros e análise técnica de produção:\n\n"${prompt}"`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: [
            "category",
            "productName",
            "size",
            "ply",
            "foldType",
            "inkColor",
            "quantity",
            "estimatedCostPerThousand",
            "recommendedPricePerThousand",
            "plateCost",
            "setupTimeHours",
            "productionDays",
            "feasibilityAnalysis",
            "designRecommendations"
          ],
          properties: {
            category: {
              type: Type.STRING,
              description: "Categoria ideal do produto: 'guardanapo', 'toalha' ou 'sache'",
            },
            productName: {
              type: Type.STRING,
              description: "Nome comercial sugerido e elegante do produto (ex: Guardanapo Cocktail Premium Folha Dupla)",
            },
            size: {
              type: Type.STRING,
              description: "Dimensões sugeridas do papel (ex: 20x20cm, 33x33cm, 5x7cm)",
            },
            ply: {
              type: Type.STRING,
              description: "Tipo de folha: 'folha_simples', 'folha_dupla' ou 'folha_tripla'",
            },
            foldType: {
              type: Type.STRING,
              description: "Tipo de dobra ideal: '1/4', '1/8', 'interfolhado' ou 'sache'",
            },
            inkColor: {
              type: Type.STRING,
              description: "Cor ou cores recomendadas para a logo/impressão (ex: Ouro Metálico, Azul Marinho, Verde Musgo 1 Cor)",
            },
            quantity: {
              type: Type.INTEGER,
              description: "Quantidade total sugerida baseada no pedido (mínimo de 5000 para guardanapo, 10000 para sachê)",
            },
            estimatedCostPerThousand: {
              type: Type.NUMBER,
              description: "Custo de fabricação estimado da fábrica por cada 1000 unidades (em Reais)",
            },
            recommendedPricePerThousand: {
              type: Type.NUMBER,
              description: "Preço de venda final recomendado para o cliente por cada 1000 unidades (em Reais)",
            },
            plateCost: {
              type: Type.NUMBER,
              description: "Custo total cobrado do cliente para gravação dos clichês fotopolímeros (em Reais)",
            },
            setupTimeHours: {
              type: Type.NUMBER,
              description: "Horas de preparação de máquina estimadas para a produção desse lote",
            },
            productionDays: {
              type: Type.INTEGER,
              description: "Dias de prazo interno sugeridos para fabricação (incluindo produção do clichê e frete)",
            },
            feasibilityAnalysis: {
              type: Type.STRING,
              description: "Texto conciso avaliando se o pedido é viável, restrições técnicas ou prazos apertados.",
            },
            designRecommendations: {
              type: Type.STRING,
              description: "Dicas de design para o clichê de impressão flexográfica (ex: evitar traços muito finos, sugerir cor metálica, etc.)",
            },
          },
        },
      },
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("Resposta vazia da IA Gemini.");
    }

    const parsedJson = JSON.parse(resultText.trim());
    return res.json(parsedJson);

  } catch (error: any) {
    console.error("Erro na rota Gemini:", error);
    return res.status(500).json({
      error: "Ocorreu um erro ao analisar o pedido com a IA.",
      details: error.message || error,
    });
  }
});

// Setup Vite Dev Server / Static Production Server
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware montado.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Servindo arquivos estáticos de produção de:", distPath);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error("Erro ao iniciar o servidor express:", err);
});
