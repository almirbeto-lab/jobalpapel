# Security Specification & "Dirty Dozen" Threat Model

This document outlines the security invariants, malicious payloads ("Dirty Dozen"), and validation requirements designed to protect the Jobal Papéis Personalizados Firestore database.

## 1. Data Invariants

1. **Id Poisoning Prevention**: Document ID path variables (e.g., `employeeId`, `machineId`, `clientId`, `orderId`) must be valid strings (`size <= 128` containing only alphanumeric characters and hyphen/underscore).
2. **Strict Field Whitelisting**: Documents must not contain extra unmapped "ghost" properties that can pollute the database.
3. **Type and Size Guarantees**: All fields must be checked for type correctness (string, number, etc.) and size limits to prevent Denial of Wallet exhaustion attacks.
4. **Machine Status State Boundary**: A machine's status can only be set to `"ocioso"`, `"produzindo"`, or `"manutencao"`.
5. **Order Status State Boundary**: An order's status can only be set to `"fila"`, `"produzindo"`, or `"finalizado"`.

---

## 2. The "Dirty Dozen" Payloads (Malicious Writes)

Below are the 12 malicious payloads designed to break the laws of Identity, Integrity, and State. All must return `PERMISSION_DENIED`.

### Payload 1: ID Poisoning on Employee Document ID
- **Path**: `/employees/VERY_LONG_GARBAGE_ID_POISONING_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH_TRASH`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 2: Employee Document with Missing Required Field `role`
- **Path**: `/employees/F-test`
- **Payload**: `{ "id": "F-test", "name": "Almir Santos", "registrationNumber": "MAT-999" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED` (missing `role`)

### Payload 3: Employee Document with Ghost Field (Pollution Attempt)
- **Path**: `/employees/F-test`
- **Payload**: `{ "id": "F-test", "name": "Almir Santos", "role": "Operador", "registrationNumber": "MAT-999", "isAdmin": true }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED` (ghost field `isAdmin` present)

### Payload 4: ID Poisoning on Machine Document ID
- **Path**: `/machines/M#$@*INVALID_CHARACTERS`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 5: Machine Document with Invalid Status Value
- **Path**: `/machines/M-test`
- **Payload**: `{ "id": "M-test", "machineNumber": "05", "name": "Flexo 05", "status": "exploding_or_broken" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 6: Machine Document with Over-sized Name Field (Resource Exhaustion)
- **Path**: `/machines/M-test`
- **Payload**: `{ "id": "M-test", "machineNumber": "05", "name": "Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05 Flexo 05", "status": "ocioso" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 7: Client Document with Missing Name
- **Path**: `/clients/C-test`
- **Payload**: `{ "id": "C-test", "email": "test@test.com" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 8: Client Document with Extra Pollution Keys
- **Path**: `/clients/C-test`
- **Payload**: `{ "id": "C-test", "name": "Pizzaria", "extraKey": "maliciousValue" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 9: Order Document with Invalid Quantity Type (String instead of Number)
- **Path**: `/orders/OP-test`
- **Payload**: `{ "id": "OP-test", "clientId": "C-1", "clientName": "Pizzaria", "productName": "Guardanapos", "quantity": "TEN_THOUSAND", "status": "fila" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 10: Order Document with Negative Quantity
- **Path**: `/orders/OP-test`
- **Payload**: `{ "id": "OP-test", "clientId": "C-1", "clientName": "Pizzaria", "productName": "Guardanapos", "quantity": -500, "status": "fila" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 11: Order Document with Invalid Status
- **Path**: `/orders/OP-test`
- **Payload**: `{ "id": "OP-test", "clientId": "C-1", "clientName": "Pizzaria", "productName": "Guardanapos", "quantity": 10000, "status": "completed_by_user" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

### Payload 12: Order Document with Ghost Field (Pollution Attempt)
- **Path**: `/orders/OP-test`
- **Payload**: `{ "id": "OP-test", "clientId": "C-1", "clientName": "Pizzaria", "productName": "Guardanapos", "quantity": 10000, "status": "fila", "fakeField": "pollute" }`
- **Action**: Create
- **Expectation**: `PERMISSION_DENIED`

---

## 3. The Rules Testing Suite

These payloads are validated against the `firestore.rules` configuration to ensure that structural integrity is mathematically locked down.
