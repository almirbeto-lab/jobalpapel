/// <reference types="vite/client" />

import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  getDocs, 
  writeBatch, 
  onSnapshot,
  setDoc,
  deleteDoc
} from "firebase/firestore";
import firebaseAppletConfig from "../firebase-applet-config.json";
import { Employee, Machine, Client, Order, INITIAL_CLIENTS, INITIAL_EMPLOYEES, INITIAL_MACHINES, INITIAL_ORDERS } from "./types";

// Permite customizar as credenciais usando variáveis de ambiente no Netlify/Vercel (com prefixo VITE_)
const firebaseConfig = {
  apiKey: (import.meta.env.VITE_FIREBASE_API_KEY as string) || firebaseAppletConfig.apiKey,
  authDomain: (import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string) || firebaseAppletConfig.authDomain,
  projectId: (import.meta.env.VITE_FIREBASE_PROJECT_ID as string) || firebaseAppletConfig.projectId,
  storageBucket: (import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string) || firebaseAppletConfig.storageBucket,
  messagingSenderId: (import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string) || firebaseAppletConfig.messagingSenderId,
  appId: (import.meta.env.VITE_FIREBASE_APP_ID as string) || firebaseAppletConfig.appId,
  firestoreDatabaseId: (import.meta.env.VITE_FIREBASE_FIRESTORE_DATABASE_ID as string) || firebaseAppletConfig.firestoreDatabaseId || "",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || "(default)");

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Helper to seed collections if they are empty so the app has initial mock/active data
export async function seedDatabaseIfEmpty() {
  try {
    const clientsRef = collection(db, "clients");
    let clientsSnap;
    try {
      clientsSnap = await getDocs(clientsRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "clients");
      return;
    }

    if (clientsSnap.empty) {
      console.log("Seeding clients to Firebase Firestore...");
      const batch = writeBatch(db);
      INITIAL_CLIENTS.forEach((c) => {
        const docRef = doc(db, "clients", c.id);
        batch.set(docRef, c);
      });
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, "clients");
      }
    }

    const employeesRef = collection(db, "employees");
    let employeesSnap;
    try {
      employeesSnap = await getDocs(employeesRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "employees");
      return;
    }

    if (employeesSnap.empty) {
      console.log("Seeding employees to Firebase Firestore...");
      const batch = writeBatch(db);
      INITIAL_EMPLOYEES.forEach((e) => {
        const docRef = doc(db, "employees", e.id);
        batch.set(docRef, e);
      });
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, "employees");
      }
    }

    const machinesRef = collection(db, "machines");
    let machinesSnap;
    try {
      machinesSnap = await getDocs(machinesRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "machines");
      return;
    }

    if (machinesSnap.empty) {
      console.log("Seeding machines to Firebase Firestore...");
      const batch = writeBatch(db);
      INITIAL_MACHINES.forEach((m) => {
        const docRef = doc(db, "machines", m.id);
        batch.set(docRef, m);
      });
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, "machines");
      }
    }

    const ordersRef = collection(db, "orders");
    let ordersSnap;
    try {
      ordersSnap = await getDocs(ordersRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "orders");
      return;
    }

    if (ordersSnap.empty) {
      console.log("Seeding orders to Firebase Firestore...");
      const batch = writeBatch(db);
      INITIAL_ORDERS.forEach((o) => {
        const docRef = doc(db, "orders", o.id);
        batch.set(docRef, o);
      });
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, "orders");
      }
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Helper to listen to a collection in real time with type safety
export function syncCollection<T>(collectionName: string, callback: (data: T[]) => void) {
  const colRef = collection(db, collectionName);
  return onSnapshot(colRef, (snapshot) => {
    const data: T[] = [];
    snapshot.forEach((doc) => {
      data.push({ ...doc.data() } as T);
    });
    callback(data);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, collectionName);
  });
}

// Helper to save or update a document
export async function saveDocument(collectionName: string, id: string, data: any) {
  const docRef = doc(db, collectionName, id);
  try {
    await setDoc(docRef, { ...data, id });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${collectionName}/${id}`);
  }
}

// Helper to delete a document
export async function removeDocument(collectionName: string, id: string) {
  const docRef = doc(db, collectionName, id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${collectionName}/${id}`);
  }
}

// Helper to reset database back to factory defaults
export async function resetFirestoreDatabase() {
  const collectionsToClean = ["clients", "employees", "machines", "orders"];
  
  try {
    const batch = writeBatch(db);
    for (const col of collectionsToClean) {
      const colRef = collection(db, col);
      let colSnap;
      try {
        colSnap = await getDocs(colRef);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, col);
        return;
      }
      colSnap.forEach((doc) => {
        batch.delete(doc.ref);
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "reset-cleanup");
  }

  // Seed INITIAL_*
  try {
    const batch2 = writeBatch(db);
    INITIAL_CLIENTS.forEach((c) => {
      batch2.set(doc(db, "clients", c.id), c);
    });
    INITIAL_EMPLOYEES.forEach((e) => {
      batch2.set(doc(db, "employees", e.id), e);
    });
    INITIAL_MACHINES.forEach((m) => {
      batch2.set(doc(db, "machines", m.id), m);
    });
    INITIAL_ORDERS.forEach((o) => {
      batch2.set(doc(db, "orders", o.id), o);
    });
    await batch2.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "reset-seeding");
  }
}

