// Core simplified domain types for the Fábrica de Papel Personalizado

export interface Employee {
  id: string;
  name: string;
  role: string;
  registrationNumber: string; // Matrícula
}

export interface Machine {
  id: string;
  machineNumber: string; // Número da Máquina (e.g., "01", "12")
  name: string;          // Nome da Máquina (e.g., "Flexográfica 4 Cores")
  status: "ocioso" | "produzindo" | "manutencao";
  currentOrderId?: string;  // OP rodando atualmente
  currentEmployeeId?: string; // Funcionário operando no momento
}

export interface Client {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  companyName?: string;
}

export interface Order {
  id: string; // e.g. "OP-101"
  clientId: string;
  clientName: string;
  productName: string;
  quantity: number;
  status: "fila" | "produzindo" | "finalizado";
  machineId?: string; // ID da Máquina designada
  employeeId?: string; // ID do Funcionário designado
}

// Initial seed data to make the app looks alive and ready right away
export const INITIAL_EMPLOYEES: Employee[] = [
  { id: "F-1", name: "Carlos Eduardo Silva", role: "Operador de Impressão", registrationNumber: "MAT-2031" },
  { id: "F-2", name: "Mariana Costa", role: "Auxiliar de Produção", registrationNumber: "MAT-2042" },
  { id: "F-3", name: "Roberto Santos", role: "Técnico Flexográfico", registrationNumber: "MAT-1088" },
];

export const INITIAL_MACHINES: Machine[] = [
  { id: "M-1", machineNumber: "01", name: "FlexoGuard 200 - Guardanapos", status: "produzindo", currentOrderId: "OP-101", currentEmployeeId: "F-1" },
  { id: "M-2", machineNumber: "02", name: "InterPapel 500 - Toalhas", status: "ocioso" },
  { id: "M-3", machineNumber: "03", name: "SachetMatic Ultra - Sachês", status: "manutencao" },
];

export const INITIAL_CLIENTS: Client[] = [
  { id: "C-1", name: "Pizzaria Bella Italia", email: "gerente@bellaitaliapizza.com", phone: "(11) 98765-4321", companyName: "Bella Italia Ltda" },
  { id: "C-2", name: "Bistrô d'Orleans", email: "contato@bistrodorleans.com.br", phone: "(21) 99122-3344", companyName: "Orleans Gastronomia" },
  { id: "C-3", name: "Copacabana Palace Hotel", email: "compras@copacabanapalace.com.br", phone: "(21) 3543-0000", companyName: "Belmond Hotels" },
];

export const INITIAL_ORDERS: Order[] = [
  { id: "OP-101", clientId: "C-1", clientName: "Pizzaria Bella Italia", productName: "Guardanapo 33x33 Folha Dupla com Logo Verde", quantity: 50000, status: "produzindo", machineId: "M-1", employeeId: "F-1" },
  { id: "OP-102", clientId: "C-2", clientName: "Bistrô d'Orleans", productName: "Guardanapo 20x20 Folha Simples com Logo Ouro", quantity: 20000, status: "fila" },
  { id: "OP-103", clientId: "C-3", clientName: "Copacabana Palace Hotel", productName: "Toalha Interfolha Luxury", quantity: 30000, status: "fila" },
];
