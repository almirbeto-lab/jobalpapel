import React, { useState, useEffect } from "react";
import {
  INITIAL_EMPLOYEES,
  INITIAL_MACHINES,
  INITIAL_CLIENTS,
  INITIAL_ORDERS,
  Employee,
  Machine,
  Client,
  Order,
} from "./types";
import {
  Cpu,
  Users,
  User,
  Plus,
  Trash2,
  Play,
  CheckCircle2,
  Layers,
  AlertTriangle,
  FolderOpen,
  UserCheck,
  Power,
  RotateCcw,
  Check,
  X,
  FileText,
  Share2,
  MessageCircle,
  Phone,
  Mail
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  seedDatabaseIfEmpty, 
  syncCollection, 
  saveDocument, 
  removeDocument, 
  resetFirestoreDatabase 
} from "./firebase";

export default function App() {
  // Persistence states synced with Firebase Firestore in real-time
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  // Current active tab
  const [activeTab, setActiveTab] = useState<"panel" | "employees" | "machines" | "clients" | "orders">("panel");

  // Sync with Firestore on mount
  useEffect(() => {
    let unsubEmployees = () => {};
    let unsubMachines = () => {};
    let unsubClients = () => {};
    let unsubOrders = () => {};

    async function setupSync() {
      // 1. Seed database with initial data if empty
      await seedDatabaseIfEmpty();

      // 2. Setup snapshot listeners
      unsubEmployees = syncCollection<Employee>("employees", (data) => {
        setEmployees(data.sort((a, b) => a.id.localeCompare(b.id)));
      });

      unsubMachines = syncCollection<Machine>("machines", (data) => {
        setMachines(data.sort((a, b) => a.machineNumber.localeCompare(b.machineNumber)));
      });

      unsubClients = syncCollection<Client>("clients", (data) => {
        setClients(data.sort((a, b) => a.name.localeCompare(b.name)));
      });

      unsubOrders = syncCollection<Order>("orders", (data) => {
        setOrders(data.sort((a, b) => a.id.localeCompare(b.id)));
      });
    }

    setupSync();

    return () => {
      unsubEmployees();
      unsubMachines();
      unsubClients();
      unsubOrders();
    };
  }, []);

  // Form states
  // 1. Employee
  const [newEmpName, setNewEmpName] = useState("");
  const [newEmpRole, setNewEmpRole] = useState("");
  const [newEmpReg, setNewEmpReg] = useState("");

  // 2. Machine
  const [newMachName, setNewMachName] = useState("");
  const [newMachNumber, setNewMachNumber] = useState("");

  // 3. Client
  const [newClientName, setNewClientName] = useState("");
  const [newClientEmail, setNewClientEmail] = useState("");
  const [newClientPhone, setNewClientPhone] = useState("");
  const [newClientCompany, setNewClientCompany] = useState("");

  // 4. OP (Order)
  const [newOpClient, setNewOpClient] = useState("");
  const [newOpProduct, setNewOpProduct] = useState("");
  const [newOpQuantity, setNewOpQuantity] = useState(10000);

  // Deletion confirmation modals
  const [empToDelete, setEmpToDelete] = useState<Employee | null>(null);
  const [machToDelete, setMachToDelete] = useState<Machine | null>(null);
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null);

  // Active run configuration state (assigning order/employee to a machine)
  const [assigningMachineId, setAssigningMachineId] = useState<string | null>(null);
  const [selectedOpToRun, setSelectedOpToRun] = useState("");
  const [selectedEmpToRun, setSelectedEmpToRun] = useState("");

  // WhatsApp Share Modal States
  const [whatsappModalOrder, setWhatsappModalOrder] = useState<Order | null>(null);
  const [whatsappPhone, setWhatsappPhone] = useState("");
  const [whatsappCustomMessage, setWhatsappCustomMessage] = useState("");
  const [whatsappIsSharingAll, setWhatsappIsSharingAll] = useState(false);

  // Handler functions
  // Reset demo data
  const handleResetData = async () => {
    if (window.confirm("Deseja redefinir os dados para o padrão de fábrica? Isso limpará seus registros atuais e reiniciará no Firebase.")) {
      try {
        await resetFirestoreDatabase();
        setAssigningMachineId(null);
        setSelectedOpToRun("");
        setSelectedEmpToRun("");
      } catch (error) {
        console.error("Error resetting data:", error);
        alert("Erro ao redefinir os dados. Verifique a conexão.");
      }
    }
  };

  // Add Employee
  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmpName.trim() || !newEmpReg.trim() || !newEmpRole.trim()) {
      alert("Por favor, preencha todos os campos do funcionário, incluindo a função.");
      return;
    }
    const newEmp: Employee = {
      id: "F-" + Date.now(),
      name: newEmpName.trim(),
      role: newEmpRole.trim(),
      registrationNumber: newEmpReg.trim(),
    };
    try {
      await saveDocument("employees", newEmp.id, newEmp);
      setNewEmpName("");
      setNewEmpReg("");
      setNewEmpRole("");
    } catch (error) {
      console.error(error);
      alert("Erro ao salvar funcionário.");
    }
  };

  // Delete Employee with mandatory Confirmation Modal
  const confirmDeleteEmployee = (employee: Employee) => {
    setEmpToDelete(employee);
  };

  const handleExecuteDeleteEmployee = async () => {
    if (!empToDelete) return;
    const id = empToDelete.id;
    try {
      // 1. Delete employee
      await removeDocument("employees", id);

      // 2. Reset any machines using this employee
      const affectedMachines = machines.filter((m) => m.currentEmployeeId === id);
      for (const m of affectedMachines) {
        await saveDocument("machines", m.id, {
          ...m,
          status: "ocioso",
          currentEmployeeId: "",
          currentOrderId: "",
        });
      }

      // 3. Reset any OPs using this employee
      const affectedOrders = orders.filter((o) => o.employeeId === id);
      for (const o of affectedOrders) {
        await saveDocument("orders", o.id, {
          ...o,
          status: "fila",
          employeeId: "",
          machineId: "",
        });
      }

      setEmpToDelete(null);
    } catch (error) {
      console.error(error);
      alert("Erro ao deletar funcionário.");
    }
  };

  // Add Machine
  const handleAddMachine = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMachName.trim() || !newMachNumber.trim()) {
      alert("Por favor, informe o nome e o número da máquina.");
      return;
    }
    const newMach: Machine = {
      id: "M-" + Date.now(),
      machineNumber: newMachNumber.trim(),
      name: newMachName.trim(),
      status: "ocioso",
    };
    try {
      await saveDocument("machines", newMach.id, newMach);
      setNewMachName("");
      setNewMachNumber("");
    } catch (error) {
      console.error(error);
      alert("Erro ao salvar máquina.");
    }
  };

  // Delete Machine
  const handleExecuteDeleteMachine = async () => {
    if (!machToDelete) return;
    const id = machToDelete.id;
    try {
      await removeDocument("machines", id);
      
      // Reset running OPs that were on this machine
      const affectedOrders = orders.filter((o) => o.machineId === id);
      for (const o of affectedOrders) {
        await saveDocument("orders", o.id, {
          ...o,
          status: "fila",
          machineId: "",
          employeeId: "",
        });
      }
      setMachToDelete(null);
    } catch (error) {
      console.error(error);
      alert("Erro ao deletar máquina.");
    }
  };

  // Delete Client
  const handleExecuteDeleteClient = async () => {
    if (!clientToDelete) return;
    const id = clientToDelete.id;
    try {
      await removeDocument("clients", id);
      
      // Also remove or clean up orders belonging to this deleted client to keep consistency
      const affectedOrders = orders.filter((o) => o.clientId === id);
      for (const o of affectedOrders) {
        await removeDocument("orders", o.id);
      }
      setClientToDelete(null);
    } catch (error) {
      console.error(error);
      alert("Erro ao deletar cliente.");
    }
  };

  // Add Client
  const handleAddClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName.trim()) {
      alert("Por favor, forneça ao menos o nome do cliente.");
      return;
    }
    const newCli: Client = {
      id: "C-" + Date.now(),
      name: newClientName.trim(),
      companyName: newClientCompany.trim() || "",
      email: newClientEmail.trim() || "",
      phone: newClientPhone.trim() || "",
    };
    try {
      await saveDocument("clients", newCli.id, newCli);
      setNewClientName("");
      setNewClientCompany("");
      setNewClientEmail("");
      setNewClientPhone("");
    } catch (error) {
      console.error(error);
      alert("Erro ao salvar cliente.");
    }
  };

  // Add OP (Production Order)
  const handleAddOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOpClient || !newOpProduct.trim() || newOpQuantity <= 0) {
      alert("Selecione um cliente, insira o produto e uma quantidade válida.");
      return;
    }
    const clientObj = clients.find((c) => c.id === newOpClient);
    if (!clientObj) return;

    const newOp: Order = {
      id: "OP-" + (orders.length + 101) + "-" + Math.floor(Math.random() * 100),
      clientId: clientObj.id,
      clientName: clientObj.name,
      productName: newOpProduct.trim(),
      quantity: newOpQuantity,
      status: "fila",
    };

    try {
      await saveDocument("orders", newOp.id, newOp);
      setNewOpProduct("");
      setNewOpQuantity(10000);
      setActiveTab("orders"); // Switch to see the new OP list
    } catch (error) {
      console.error(error);
      alert("Erro ao salvar ordem de produção.");
    }
  };

  // WhatsApp Share Handlers
  const handleOpenWhatsAppShare = (order: Order) => {
    const clientObj = clients.find((c) => c.id === order.clientId);
    const machine = machines.find((m) => m.id === order.machineId);
    const employee = employees.find((e) => e.id === order.employeeId);

    // Prefill phone if available
    let phonePrefill = "";
    if (clientObj && clientObj.phone) {
      phonePrefill = clientObj.phone.replace(/\D/g, "");
      // Brazil country code prefill fallback
      if (phonePrefill.length > 0 && !phonePrefill.startsWith("55") && phonePrefill.length >= 10) {
        phonePrefill = "55" + phonePrefill;
      }
    }

    const statusIcon = order.status === "finalizado" ? "🟢" : order.status === "produzindo" ? "🔵" : "🟡";
    const statusText = order.status === "finalizado" ? "FINALIZADO" : order.status === "produzindo" ? "EM PRODUÇÃO (RODANDO)" : "AGUARDANDO NA FILA";

    const text = `*JOBAL - PAPÉIS PERSONALIZADOS* 📄🟢
*REGISTRO DE FABRICAÇÃO DE OP*

*Código da OP:* ${order.id}
*Cliente:* ${order.clientName}
*Produto:* ${order.productName}
*Quantidade:* ${order.quantity.toLocaleString("pt-BR")} unidades
*Status:* ${statusIcon} ${statusText}
${machine ? `*Máquina:* Nº ${machine.machineNumber} - ${machine.name}` : ""}
${employee ? `*Operador Responsável:* ${employee.name}` : ""}

_Enviado via Terminal de Gestão Operacional Jobal_`;

    setWhatsappModalOrder(order);
    setWhatsappIsSharingAll(false);
    setWhatsappPhone(phonePrefill || "");
    setWhatsappCustomMessage(text);
  };

  const handleOpenWhatsAppShareAll = () => {
    const running = orders.filter((o) => o.status === "produzindo");
    const finished = orders.filter((o) => o.status === "finalizado");
    const queued = orders.filter((o) => o.status === "fila");

    let text = `*JOBAL - PAPÉIS PERSONALIZADOS* 📄🟢\n`;
    text += `*RESUMO OPERACIONAL DE PRODUÇÃO* 📊\n\n`;

    text += `*🔄 EM PRODUÇÃO (${running.length}):*\n`;
    if (running.length === 0) {
      text += `_Nenhuma OP em andamento no momento_\n`;
    } else {
      running.forEach((o) => {
        const machine = machines.find((m) => m.id === o.machineId);
        const machineStr = machine ? ` (Máq. ${machine.machineNumber})` : "";
        text += `- *${o.id}*: ${o.clientName} | ${o.productName} | ${o.quantity.toLocaleString("pt-BR")} un${machineStr}\n`;
      });
    }

    text += `\n*✅ CONCLUÍDAS (${finished.length}):*\n`;
    if (finished.length === 0) {
      text += `_Nenhum lote concluído ainda_\n`;
    } else {
      finished.forEach((o) => {
        text += `- *${o.id}*: ${o.clientName} | ${o.productName} | ${o.quantity.toLocaleString("pt-BR")} un\n`;
      });
    }

    text += `\n*⏳ NA FILA (${queued.length}):*\n`;
    if (queued.length === 0) {
      text += `_Nenhuma OP aguardando na fila_\n`;
    } else {
      queued.forEach((o) => {
        text += `- *${o.id}*: ${o.clientName} | ${o.productName} | ${o.quantity.toLocaleString("pt-BR")} un\n`;
      });
    }

    text += `\n_Gerado em: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}_\n`;
    text += `_Terminal de Gestão Operacional Jobal_`;

    setWhatsappModalOrder(null);
    setWhatsappIsSharingAll(true);
    setWhatsappPhone("");
    setWhatsappCustomMessage(text);
  };

  const handleSendWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = whatsappPhone.replace(/\D/g, "");
    
    const baseUrl = cleanPhone ? `https://api.whatsapp.com/send?phone=${cleanPhone}` : "https://api.whatsapp.com/send";
    const finalUrl = `${baseUrl}&text=${encodeURIComponent(whatsappCustomMessage)}`;
    
    window.open(finalUrl, "_blank");
    
    // Reset modal states
    setWhatsappModalOrder(null);
    setWhatsappIsSharingAll(false);
    setWhatsappPhone("");
    setWhatsappCustomMessage("");
  };

  // Start Production (Assign Employee and OP to Machine)
  const handleStartProduction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assigningMachineId || !selectedOpToRun || !selectedEmpToRun) {
      alert("Selecione um funcionário e uma OP pendente para iniciar.");
      return;
    }

    try {
      const machineObj = machines.find((m) => m.id === assigningMachineId);
      if (machineObj) {
        await saveDocument("machines", machineObj.id, {
          ...machineObj,
          status: "produzindo",
          currentOrderId: selectedOpToRun,
          currentEmployeeId: selectedEmpToRun,
        });
      }

      const orderObj = orders.find((o) => o.id === selectedOpToRun);
      if (orderObj) {
        await saveDocument("orders", orderObj.id, {
          ...orderObj,
          status: "produzindo",
          machineId: assigningMachineId,
          employeeId: selectedEmpToRun,
        });
      }

      // Reset setup states
      setAssigningMachineId(null);
      setSelectedOpToRun("");
      setSelectedEmpToRun("");
    } catch (error) {
      console.error(error);
      alert("Erro ao iniciar produção.");
    }
  };

  // Finish Production / Stop Machine
  const handleFinishProduction = async (machineId: string, orderId?: string) => {
    if (!orderId) return;

    try {
      const machineObj = machines.find((m) => m.id === machineId);
      if (machineObj) {
        await saveDocument("machines", machineObj.id, {
          ...machineObj,
          status: "ocioso",
          currentOrderId: "",
          currentEmployeeId: "",
        });
      }

      const orderObj = orders.find((o) => o.id === orderId);
      if (orderObj) {
        await saveDocument("orders", orderObj.id, {
          ...orderObj,
          status: "finalizado",
        });
      }
    } catch (error) {
      console.error(error);
      alert("Erro ao finalizar produção.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-brand-green-light selection:text-white">
      {/* Upper Navigation Header */}
      <header className="bg-brand-green sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {/* Elegant SVG replica of Jobal Papéis Personalizados logo */}
            <div className="flex items-center">
              <svg viewBox="0 0 160 80" className="h-16 w-auto" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Thin elegant white orbit/swoosh */}
                <ellipse cx="80" cy="38" rx="72" ry="26" stroke="white" strokeWidth="1.5" strokeOpacity="0.9" transform="rotate(-5 80 38)" />
                
                {/* Jobal Text using elegant serif/cursive fallback */}
                <text x="78" y="44" textAnchor="middle" fill="white" fontSize="28" fontWeight="900" fontStyle="italic" fontFamily="Georgia, serif">
                  Jobal
                </text>
                
                {/* PAPÉIS PERSONALIZADOS text below */}
                <text x="80" y="59" textAnchor="middle" fill="#a3d9b9" fontSize="6" fontWeight="900" letterSpacing="1.8" fontFamily="sans-serif">
                  PAPÉIS PERSONALIZADOS
                </text>
              </svg>
            </div>
            
            <div className="hidden md:block border-l border-white/20 pl-4 py-1">
              <h1 className="font-sans font-black text-white text-base tracking-tight">
                Gestão de Produção Flexográfica
              </h1>
              <p className="text-[11px] text-[#a3d9b9] font-medium">Controle de Máquinas, Funcionários, Clientes e OPs</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden sm:inline-block text-[10px] bg-brand-green-medium/50 text-white border border-white/10 px-3 py-1 rounded-full font-mono font-bold uppercase tracking-wider">
              Simplificado
            </span>
            <button
              onClick={handleResetData}
              title="Redefinir Dados de Fábrica"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/10 text-white transition text-xs font-bold shadow-xs cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Resetar</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Tab Navigation */}
      <nav className="bg-white border-b border-slate-200 backdrop-blur-sm sticky top-20 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-2 py-2.5 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveTab("panel")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition duration-200 shrink-0 cursor-pointer ${
                activeTab === "panel"
                  ? "bg-brand-green text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              }`}
            >
              <Cpu className="w-4 h-4" />
              Painel de Operação (OP)
            </button>

            <button
              onClick={() => setActiveTab("employees")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition duration-200 shrink-0 cursor-pointer ${
                activeTab === "employees"
                  ? "bg-brand-green text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              }`}
            >
              <Users className="w-4 h-4" />
              Funcionários ({employees.length})
            </button>

            <button
              onClick={() => setActiveTab("machines")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition duration-200 shrink-0 cursor-pointer ${
                activeTab === "machines"
                  ? "bg-brand-green text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              }`}
            >
              <Power className="w-4 h-4" />
              Máquinas ({machines.length})
            </button>

            <button
              onClick={() => setActiveTab("clients")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition duration-200 shrink-0 cursor-pointer ${
                activeTab === "clients"
                  ? "bg-brand-green text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              }`}
            >
              <User className="w-4 h-4" />
              Clientes ({clients.length})
            </button>

            <button
              onClick={() => setActiveTab("orders")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition duration-200 shrink-0 cursor-pointer ${
                activeTab === "orders"
                  ? "bg-brand-green text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              }`}
            >
              <FileText className="w-4 h-4" />
              Ordens de Produção ({orders.length})
            </button>
          </div>
        </div>
      </nav>

      {/* Main Workspace Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {/* TAB 1: OPERATIONAL PANEL (ASSIGN AND MONITORS OPS AND EMPLOYEES ON MACHINES) */}
          {activeTab === "panel" && (
            <motion.div
              key="panel"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6"
            >
              {/* Alert if no setups exist */}
              {machines.length === 0 && (
                <div className="p-5 bg-amber-50 border border-amber-200 rounded-xl flex gap-3 text-sm text-amber-800">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                  <div>
                    <h4 className="font-bold">Nenhuma Máquina Cadastrada!</h4>
                    <p className="mt-1">Cadastre as máquinas na aba "Máquinas" para poder gerenciar a produção.</p>
                  </div>
                </div>
              )}

              {/* Status Header */}
              <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                <div>
                  <h2 className="text-xl font-black text-slate-900">Maquinário Ativo e Ordens de Serviço (OP)</h2>
                  <p className="text-xs text-slate-500 font-medium">Ligue funcionários às máquinas e coloque as OPs para rodar</p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={handleOpenWhatsAppShareAll}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-brand-green hover:bg-brand-green-medium text-white rounded-xl text-xs font-bold shadow-xs transition duration-150 cursor-pointer"
                    title="Enviar resumo de todas as máquinas e OPs para o WhatsApp"
                  >
                    <MessageCircle className="w-4 h-4 fill-current" />
                    <span>Enviar Resumo p/ WhatsApp</span>
                  </button>

                  <div className="flex gap-3 text-xs bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                    <div className="flex items-center gap-1.5 px-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" />
                      <span className="font-bold text-slate-700">
                        {machines.filter((m) => m.status === "produzindo").length} Rodando
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2 border-l border-slate-200">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                      <span className="font-bold text-slate-700">
                        {machines.filter((m) => m.status === "ocioso").length} Ociosas
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2 border-l border-slate-200">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-400" />
                      <span className="font-bold text-slate-700">
                        {machines.filter((m) => m.status === "manutencao").length} Manutenção
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Grid of machines on the factory floor */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {machines.map((machine) => {
                  const runningOp = orders.find((o) => o.id === machine.currentOrderId);
                  const activeEmployee = employees.find((e) => e.id === machine.currentEmployeeId);

                  return (
                    <div
                      key={machine.id}
                      className={`bg-white border rounded-2xl p-6 pt-7 flex flex-col justify-between relative overflow-hidden shadow-sm transition-all duration-200 hover:shadow-md ${
                        machine.status === "produzindo"
                          ? "border-brand-green-light ring-2 ring-brand-green/10"
                          : machine.status === "manutencao"
                          ? "border-red-200 bg-red-50/10"
                          : "border-slate-200"
                      }`}
                    >
                      {/* Top status color strip */}
                      <div
                        className={`absolute top-0 inset-x-0 h-1.5 ${
                          machine.status === "produzindo"
                            ? "bg-gradient-to-r from-brand-green to-brand-green-light"
                            : machine.status === "manutencao"
                            ? "bg-gradient-to-r from-amber-500 to-red-500"
                            : "bg-slate-200"
                        }`}
                      />
                      {/* Machine Badge and ID */}
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                        <div>
                          <span className="text-[10px] font-mono text-slate-400 font-bold uppercase block">
                            Máquina Nº {machine.machineNumber}
                          </span>
                          <h3 className="font-bold text-slate-900 text-base mt-0.5">{machine.name}</h3>
                        </div>
                        <span
                          className={`text-[9px] font-bold font-mono uppercase px-2.5 py-1 rounded-full ${
                            machine.status === "produzindo"
                              ? "bg-green-50 text-green-700 border border-green-100"
                              : machine.status === "manutencao"
                              ? "bg-red-50 text-red-700 border border-red-100"
                              : "bg-slate-100 text-slate-600 border border-slate-200"
                          }`}
                        >
                          {machine.status === "produzindo"
                            ? "Produzindo"
                            : machine.status === "manutencao"
                            ? "Manutenção"
                            : "Ocioso"}
                        </span>
                      </div>

                      {/* Info Panel: Employee and OP assigned */}
                      <div className="flex-1 space-y-4 py-2">
                        {machine.status === "produzindo" && runningOp && activeEmployee ? (
                          <div className="space-y-3.5">
                            {/* Running OP info */}
                            <div className="bg-brand-green-soft/60 p-3 rounded-xl border border-brand-green/20">
                              <span className="text-[9px] font-mono uppercase tracking-wider text-brand-green block font-bold">
                                Ordem de Produção Ativa
                              </span>
                              <div className="flex justify-between items-center mt-1">
                                <span className="font-mono font-bold text-brand-green text-xs">{runningOp.id}</span>
                                <span className="text-[11px] text-slate-500 font-bold">{runningOp.clientName}</span>
                              </div>
                              <p className="text-xs text-slate-700 font-semibold mt-1.5 leading-tight">
                                {runningOp.productName}
                              </p>
                              <p className="text-[10px] font-mono text-slate-400 font-bold mt-1 text-right">
                                Lote: {runningOp.quantity.toLocaleString()} un
                              </p>
                              <button
                                type="button"
                                onClick={() => handleOpenWhatsAppShare(runningOp)}
                                className="mt-2.5 w-full flex items-center justify-center gap-1.5 py-1.5 bg-[#25d366]/10 hover:bg-[#25d366]/20 text-[#128c7e] font-extrabold text-[11px] rounded-lg transition cursor-pointer"
                                title="Enviar registro deste lote via WhatsApp"
                              >
                                <MessageCircle className="w-3.5 h-3.5 fill-current" /> Enviar p/ WhatsApp
                              </button>
                            </div>

                            {/* Assigned worker info */}
                            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center gap-2.5">
                              <div className="p-1.5 bg-brand-green-soft text-brand-green rounded-lg shrink-0">
                                <UserCheck className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <span className="text-[9px] font-mono uppercase text-slate-400 block font-bold">
                                  Operador Responsável
                                </span>
                                <p className="text-xs font-bold text-slate-800 truncate">{activeEmployee.name}</p>
                                <p className="text-[10px] text-slate-500 font-mono">{activeEmployee.registrationNumber}</p>
                              </div>
                            </div>
                          </div>
                        ) : machine.status === "manutencao" ? (
                          <div className="py-8 text-center flex flex-col items-center justify-center">
                            <AlertTriangle className="w-8 h-8 text-red-500 mb-2" />
                            <p className="text-xs text-slate-500 font-bold">Equipamento indisponível</p>
                            <p className="text-[10px] text-slate-400 font-medium">Sob manutenção preventiva / corretiva</p>
                            <button
                              onClick={async () => {
                                try {
                                  await saveDocument("machines", machine.id, { ...machine, status: "ocioso" });
                                } catch (error) {
                                  console.error(error);
                                }
                              }}
                              className="mt-3 text-[10px] bg-white hover:bg-slate-50 text-slate-600 font-bold py-1 px-2.5 border border-slate-200 rounded transition cursor-pointer shadow-2xs"
                            >
                              Marcar como Ociosa (Pronta)
                            </button>
                          </div>
                        ) : (
                          <div className="py-6 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/50 flex flex-col items-center justify-center">
                            <Power className="w-7 h-7 text-slate-300 mb-1.5" />
                            <p className="text-xs text-slate-500 font-bold">Nenhuma OP rodando</p>
                            <p className="text-[10px] text-slate-400 font-semibold mb-3">Máquina livre para produção</p>
                            
                            {assigningMachineId !== machine.id ? (
                              <button
                                onClick={() => {
                                  setAssigningMachineId(machine.id);
                                  // Auto preselect first available if options are empty
                                  const pendingOps = orders.filter((o) => o.status === "fila");
                                  if (pendingOps.length > 0) setSelectedOpToRun(pendingOps[0].id);
                                  if (employees.length > 0) setSelectedEmpToRun(employees[0].id);
                                }}
                                className="bg-brand-green hover:bg-brand-green-medium text-white font-bold text-xs py-1.5 px-3.5 rounded-lg flex items-center gap-1 shadow-xs transition cursor-pointer"
                              >
                                <Play className="w-3.5 h-3.5 fill-current" /> Configurar Lote (OP)
                              </button>
                            ) : (
                              <button
                                onClick={() => setAssigningMachineId(null)}
                                className="text-slate-500 hover:text-slate-800 text-[10px] font-bold py-1 px-2 hover:bg-slate-100 rounded transition"
                              >
                                Cancelar
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Action buttons footer */}
                      <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                        {machine.status === "produzindo" ? (
                          <button
                            onClick={() => handleFinishProduction(machine.id, machine.currentOrderId)}
                            className="bg-green-600 hover:bg-green-700 text-white font-bold text-xs py-1.5 px-4 rounded-lg flex items-center gap-1 shadow-xs transition cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> Finalizar OP / Parar
                          </button>
                        ) : machine.status === "ocioso" ? (
                          <div className="flex gap-2">
                            <button
                              onClick={async () => {
                                try {
                                  await saveDocument("machines", machine.id, { ...machine, status: "manutencao" });
                                } catch (error) {
                                  console.error(error);
                                }
                              }}
                              className="bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 font-bold text-[10px] py-1 px-2.5 rounded transition cursor-pointer"
                            >
                              Manutenção
                            </button>
                          </div>
                        ) : null}
                      </div>

                      {/* INLINE POPUP SETUP: Assigning employee & OP to run */}
                      <AnimatePresence>
                        {assigningMachineId === machine.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="absolute inset-x-0 bottom-0 bg-white border-t border-slate-200 p-5 z-10 shadow-2xl space-y-3.5"
                          >
                            <div className="flex justify-between items-center pb-1 border-b border-slate-100">
                              <h4 className="font-bold text-xs text-slate-800">Iniciar Nova Produção</h4>
                              <button onClick={() => setAssigningMachineId(null)} className="p-1 text-slate-400 hover:text-slate-600 rounded">
                                <X className="w-4 h-4" />
                              </button>
                            </div>

                            <form onSubmit={handleStartProduction} className="space-y-3 text-xs text-left">
                              {/* 1. Select OP */}
                              <div>
                                <label className="block text-[10px] uppercase font-mono tracking-wide text-slate-400 font-bold mb-1">
                                  Selecione a Ordem de Produção (OP)
                                </label>
                                {orders.filter((o) => o.status === "fila").length > 0 ? (
                                  <select
                                    value={selectedOpToRun}
                                    onChange={(e) => setSelectedOpToRun(e.target.value)}
                                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-700 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green"
                                  >
                                    {orders
                                      .filter((o) => o.status === "fila")
                                      .map((o) => (
                                        <option key={o.id} value={o.id}>
                                          {o.id} - {o.clientName} ({o.productName} - {o.quantity.toLocaleString()} un)
                                        </option>
                                      ))}
                                  </select>
                                ) : (
                                  <div className="p-2 text-center text-red-500 bg-red-50 border border-red-100 rounded-lg font-bold text-[11px]">
                                    Nenhuma OP na fila! Crie uma OP na aba correspondente primeiro.
                                  </div>
                                )}
                              </div>

                              {/* 2. Select Employee */}
                              <div>
                                <label className="block text-[10px] uppercase font-mono tracking-wide text-slate-400 font-bold mb-1">
                                  Escalar Funcionário (Operador)
                                </label>
                                {employees.length > 0 ? (
                                  <select
                                    value={selectedEmpToRun}
                                    onChange={(e) => setSelectedEmpToRun(e.target.value)}
                                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-700 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green"
                                  >
                                    {employees.map((e) => (
                                      <option key={e.id} value={e.id}>
                                        {e.name} ({e.registrationNumber}) - {e.role}
                                      </option>
                                    ))}
                                  </select>
                                ) : (
                                  <div className="p-2 text-center text-red-500 bg-red-50 border border-red-100 rounded-lg font-bold text-[11px]">
                                    Nenhum funcionário cadastrado! Crie um primeiro.
                                  </div>
                                )}
                              </div>

                              <button
                                type="submit"
                                disabled={
                                  orders.filter((o) => o.status === "fila").length === 0 ||
                                  employees.length === 0
                                }
                                className="w-full py-2 bg-brand-green hover:bg-brand-green-medium text-white font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-sm transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                              >
                                <Play className="w-3.5 h-3.5 fill-current" /> Ativar Maquinário & Lote
                              </button>
                            </form>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* TAB 2: EMPLOYEES (CADASTRO E LISTAGEM COM DELETAR + CONFIRMAR) */}
          {activeTab === "employees" && (
            <motion.div
              key="employees"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Form on left side */}
              <div className="lg:col-span-4 space-y-6">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-950 text-base mb-1.5 flex items-center gap-2">
                    <Plus className="w-5 h-5 text-brand-green" /> Cadastrar Funcionário
                  </h3>
                  <p className="text-xs text-slate-500 mb-5">Adicione operadores e auxiliares para a escala flexográfica</p>

                  <form onSubmit={handleAddEmployee} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Nome Completo
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: João Ferreira de Souza"
                        value={newEmpName}
                        onChange={(e) => setNewEmpName(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Nº da Matrícula / Registro
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: MAT-3490"
                        value={newEmpReg}
                        onChange={(e) => setNewEmpReg(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold font-mono tracking-wider focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Função na Linha
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Operador de Impressão, Auxiliar, etc."
                        value={newEmpRole}
                        onChange={(e) => setNewEmpRole(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-brand-green hover:bg-brand-green-medium text-white font-bold rounded-lg flex items-center justify-center gap-1.5 transition shadow-md cursor-pointer mt-2"
                    >
                      <Plus className="w-4 h-4" /> Cadastrar Funcionário
                    </button>
                  </form>
                </div>
              </div>

              {/* List of registered employees on right side */}
              <div className="lg:col-span-8">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-900 text-base mb-4">Funcionários Ativos</h3>
                  
                  {employees.length === 0 ? (
                    <div className="text-center py-10 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                      <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs text-slate-400 font-bold">Nenhum funcionário cadastrado no sistema</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-500 font-mono text-[10px] uppercase tracking-wider bg-slate-50">
                            <th className="p-3">Matrícula</th>
                            <th className="p-3">Nome</th>
                            <th className="p-3">Função</th>
                            <th className="p-3 text-right">Ação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                          {employees.map((emp) => (
                            <tr key={emp.id} className="hover:bg-slate-50/50 transition">
                              <td className="p-3 font-mono font-bold text-brand-green">{emp.registrationNumber}</td>
                              <td className="p-3 font-bold text-slate-900">{emp.name}</td>
                              <td className="p-3 font-medium text-slate-500">{emp.role}</td>
                              <td className="p-3 text-right">
                                <button
                                  onClick={() => confirmDeleteEmployee(emp)}
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-lg border border-transparent hover:border-red-100 transition cursor-pointer"
                                  title="Deletar Funcionário"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 3: MACHINES (CADASTRO E LISTAGEM COM DELETAR) */}
          {activeTab === "machines" && (
            <motion.div
              key="machines"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Form on left side */}
              <div className="lg:col-span-4 space-y-6">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-950 text-base mb-1.5 flex items-center gap-2">
                    <Plus className="w-5 h-5 text-brand-green" /> Cadastrar Máquina
                  </h3>
                  <p className="text-xs text-slate-500 mb-5">Adicione maquinário rotativo flexográfico informando o número identificador</p>

                  <form onSubmit={handleAddMachine} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Número da Máquina
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: 01, 12, A-3"
                        value={newMachNumber}
                        onChange={(e) => setNewMachNumber(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-black font-mono tracking-wider focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Nome / Descrição do Equipamento
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: FlexoGuard 200 - Guardanapos"
                        value={newMachName}
                        onChange={(e) => setNewMachName(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-brand-green hover:bg-brand-green-medium text-white font-bold rounded-lg flex items-center justify-center gap-1.5 transition shadow-md cursor-pointer mt-2"
                    >
                      <Plus className="w-4 h-4" /> Cadastrar Máquina
                    </button>
                  </form>
                </div>
              </div>

              {/* List of registered machines on right side */}
              <div className="lg:col-span-8">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-900 text-base mb-4">Máquinas Cadastradas</h3>
                  
                  {machines.length === 0 ? (
                    <div className="text-center py-10 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                      <Cpu className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs text-slate-400 font-bold">Nenhuma máquina cadastrada no sistema</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-500 font-mono text-[10px] uppercase tracking-wider bg-slate-50">
                            <th className="p-3">Nº da Máquina</th>
                            <th className="p-3">Equipamento</th>
                            <th className="p-3">Status Atual</th>
                            <th className="p-3 text-right">Ação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                          {machines.map((mach) => (
                            <tr key={mach.id} className="hover:bg-slate-50/50 transition">
                              <td className="p-3 font-mono font-black text-slate-900 text-sm">#{mach.machineNumber}</td>
                              <td className="p-3 font-bold text-slate-800">{mach.name}</td>
                              <td className="p-3">
                                <span
                                  className={`text-[9px] font-bold font-mono uppercase px-2 py-0.5 rounded-full ${
                                    mach.status === "produzindo"
                                      ? "bg-green-50 text-green-700"
                                      : mach.status === "manutencao"
                                      ? "bg-red-50 text-red-700"
                                      : "bg-slate-100 text-slate-600"
                                  }`}
                                >
                                  {mach.status}
                                </span>
                              </td>
                              <td className="p-3 text-right">
                                <button
                                  onClick={() => setMachToDelete(mach)}
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-lg transition cursor-pointer"
                                  title="Deletar Máquina"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 4: CLIENTS (CADASTRO E LISTAGEM) */}
          {activeTab === "clients" && (
            <motion.div
              key="clients"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Form on left side */}
              <div className="lg:col-span-4 space-y-6">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-950 text-base mb-1.5 flex items-center gap-2">
                    <Plus className="w-5 h-5 text-brand-green" /> Cadastrar Cliente
                  </h3>
                  <p className="text-xs text-slate-500 mb-5">Adicione clientes para emissão e personalização de OPs</p>

                  <form onSubmit={handleAddClient} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Nome do Contato
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Carlos d'Orleans"
                        value={newClientName}
                        onChange={(e) => setNewClientName(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Razão Social / Empresa (Opcional)
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Orleans Gastronomia Ltda"
                        value={newClientCompany}
                        onChange={(e) => setNewClientCompany(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Telefone / WhatsApp (Opcional)
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: (11) 98765-4321"
                        value={newClientPhone}
                        onChange={(e) => setNewClientPhone(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        E-mail de Contato (Opcional)
                      </label>
                      <input
                        type="email"
                        placeholder="Ex: contato@bistrodorleans.com.br"
                        value={newClientEmail}
                        onChange={(e) => setNewClientEmail(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-brand-green hover:bg-brand-green-medium text-white font-bold rounded-lg flex items-center justify-center gap-1.5 transition shadow-md cursor-pointer mt-2"
                    >
                      <Plus className="w-4 h-4" /> Cadastrar Cliente
                    </button>
                  </form>
                </div>
              </div>

              {/* List of registered clients on right side */}
              <div className="lg:col-span-8">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-900 text-base mb-4">Clientes Registrados</h3>
                  
                  {clients.length === 0 ? (
                    <div className="text-center py-10 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                      <User className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs text-slate-400 font-bold">Nenhum cliente cadastrado no sistema</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-500 font-mono text-[10px] uppercase tracking-wider bg-slate-50">
                            <th className="p-3">Nome</th>
                            <th className="p-3">Empresa</th>
                            <th className="p-3">WhatsApp</th>
                            <th className="p-3">E-mail</th>
                            <th className="p-3 text-right">Ação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                          {clients.map((cli) => (
                            <tr key={cli.id} className="hover:bg-slate-50/50 transition">
                              <td className="p-3 font-bold text-slate-900">{cli.name}</td>
                              <td className="p-3 text-slate-500 font-semibold">{cli.companyName || "Pessoa Física"}</td>
                              <td className="p-3 font-mono font-bold text-brand-green-light">{cli.phone || "—"}</td>
                              <td className="p-3 font-mono text-slate-500">{cli.email || "—"}</td>
                              <td className="p-3 text-right">
                                <button
                                  onClick={() => setClientToDelete(cli)}
                                  className="text-red-400 hover:text-red-600 p-1 rounded transition cursor-pointer"
                                  title="Deletar Cliente"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 5: PRODUCTION ORDERS (OP - LISTAGEM E CADASTRO) */}
          {activeTab === "orders" && (
            <motion.div
              key="orders"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Form on left side */}
              <div className="lg:col-span-4 space-y-6">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-950 text-base mb-1.5 flex items-center gap-2">
                    <Plus className="w-5 h-5 text-brand-green" /> Emitir Nova OP
                  </h3>
                  <p className="text-xs text-slate-500 mb-5">Crie uma nova ordem de produção vinculada a um cliente cadastrado</p>

                  <form onSubmit={handleAddOrder} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Selecione o Cliente
                      </label>
                      {clients.length > 0 ? (
                        <select
                          value={newOpClient}
                          onChange={(e) => setNewOpClient(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-700 font-bold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-xs"
                        >
                          <option value="">-- Selecione o Cliente --</option>
                          {clients.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name} ({c.companyName || "PF"})
                            </option>
                          ))}
                        </select>
                      ) : (
                        <div className="p-3 text-red-500 bg-red-50 border border-red-100 rounded-lg font-semibold leading-tight text-[11px]">
                          Nenhum cliente cadastrado! Por favor, vá na aba "Clientes" e faça o cadastro primeiro.
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Especificação / Produto da OP
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Guardanapo 40x40 Folha Dupla Logotipo Ouro"
                        value={newOpProduct}
                        onChange={(e) => setNewOpProduct(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                        Quantidade Unidade
                      </label>
                      <input
                        type="number"
                        step={5000}
                        min={1000}
                        value={newOpQuantity}
                        onChange={(e) => setNewOpQuantity(parseInt(e.target.value) || 0)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 font-bold font-mono focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={clients.length === 0}
                      className="w-full py-2.5 bg-brand-green hover:bg-brand-green-medium text-white font-bold rounded-lg flex items-center justify-center gap-1.5 transition shadow-md cursor-pointer mt-2 disabled:opacity-40"
                    >
                      <Plus className="w-4 h-4" /> Emitir Ordem (OP)
                    </button>
                  </form>
                </div>
              </div>

              {/* List of registered orders on right side */}
              <div className="lg:col-span-8">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-sans font-black text-slate-900 text-base mb-4">Registro Geral de OPs</h3>
                  
                  {orders.length === 0 ? (
                    <div className="text-center py-10 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                      <FolderOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs text-slate-400 font-bold">Nenhuma ordem de produção ativa</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-500 font-mono text-[10px] uppercase tracking-wider bg-slate-50">
                            <th className="p-3">Código OP</th>
                            <th className="p-3">Cliente</th>
                            <th className="p-3">Produto</th>
                            <th className="p-3">Quantidade Unidade</th>
                            <th className="p-3">Escala</th>
                            <th className="p-3">Status</th>
                            <th className="p-3 text-right">Ações</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                          {orders.map((op) => {
                            const assignedMachine = machines.find((m) => m.id === op.machineId);
                            const assignedEmployee = employees.find((e) => e.id === op.employeeId);

                            return (
                              <tr key={op.id} className="hover:bg-slate-50/50 transition">
                                <td className="p-3 font-mono font-bold text-brand-green-light">{op.id}</td>
                                <td className="p-3 font-bold text-slate-900">{op.clientName}</td>
                                <td className="p-3 font-semibold text-slate-700 leading-tight">{op.productName}</td>
                                <td className="p-3 font-mono font-bold text-slate-800">{op.quantity.toLocaleString()} un</td>
                                <td className="p-3">
                                  {op.status === "produzindo" && assignedMachine && assignedEmployee ? (
                                    <div className="space-y-0.5 text-[10px] font-medium leading-tight">
                                      <div className="text-brand-green font-bold">Máq. #{assignedMachine.machineNumber}</div>
                                      <div className="text-slate-500 font-semibold">{assignedEmployee.name}</div>
                                    </div>
                                  ) : (
                                    <span className="text-slate-400 font-mono italic text-[11px]">Não alocado</span>
                                  )}
                                </td>
                                <td className="p-3">
                                  <span
                                    className={`text-[9px] font-bold font-mono uppercase px-2.5 py-1 rounded-full ${
                                      op.status === "produzindo"
                                        ? "bg-brand-green-soft text-brand-green font-extrabold"
                                        : op.status === "finalizado"
                                        ? "bg-green-50 text-green-700"
                                        : "bg-amber-50 text-amber-700"
                                    }`}
                                  >
                                    {op.status === "produzindo"
                                      ? "Rodando"
                                      : op.status === "finalizado"
                                      ? "Finalizado"
                                      : "Na Fila"}
                                  </span>
                                </td>
                                <td className="p-3 text-right">
                                  <button
                                    onClick={() => handleOpenWhatsAppShare(op)}
                                    className="inline-flex items-center gap-1 px-2 py-1 bg-[#25d366]/15 hover:bg-[#25d366]/25 text-[#128c7e] font-extrabold text-[10px] rounded-lg transition cursor-pointer"
                                    title="Enviar Registro por WhatsApp"
                                  >
                                    <MessageCircle className="w-3.5 h-3.5 fill-current" />
                                    <span>WhatsApp</span>
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-auto py-8 bg-white border-t border-slate-200 text-center text-xs text-slate-400 font-mono font-medium shadow-xs">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p className="font-bold text-brand-green text-sm">Jobal Papéis Personalizados</p>
          <p>© 2026 Jobal Embalagens Ltda. Terminal Simplificado de Gestão Operacional.</p>
        </div>
      </footer>

      {/* GLOBAL MODAL: MANDATORY CONFIRMATION TO DELETE EMPLOYEE */}
      <AnimatePresence>
        {empToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Dark blur backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setEmpToDelete(null)}
              className="absolute inset-0 bg-slate-900"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-md w-full relative z-10 text-slate-800 space-y-4"
            >
              <div className="flex items-start gap-3">
                <div className="p-3 bg-red-100 text-red-600 rounded-full shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Tem certeza que deseja excluir?</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Você está prestes a remover permanentemente este funcionário do sistema. Esta ação não poderá ser desfeita.
                  </p>
                </div>
              </div>

              {/* Target worker details card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
                <span className="text-[9px] font-mono uppercase tracking-wide text-slate-400 font-bold block">
                  Funcionário Selecionado
                </span>
                <p className="font-bold text-slate-900 text-sm">{empToDelete.name}</p>
                <p className="text-xs font-mono text-slate-500">Matrícula: {empToDelete.registrationNumber}</p>
                <p className="text-xs font-medium text-slate-400 mt-0.5">{empToDelete.role}</p>
              </div>

              {/* Alert message */}
              <p className="text-[11px] text-red-600 font-bold bg-red-50 border border-red-100 p-2.5 rounded-lg leading-relaxed">
                Aviso: Se este funcionário estiver atualmente escalado em alguma máquina ativa, a produção será pausada e a máquina retornará ao estado ocioso.
              </p>

              {/* Control triggers */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setEmpToDelete(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleExecuteDeleteEmployee}
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm transition cursor-pointer"
                >
                  Sim, Deletar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GLOBAL MODAL: MANDATORY CONFIRMATION TO DELETE MACHINE */}
      <AnimatePresence>
        {machToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Dark blur backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setMachToDelete(null)}
              className="absolute inset-0 bg-slate-900"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-md w-full relative z-10 text-slate-800 space-y-4"
            >
              <div className="flex items-start gap-3">
                <div className="p-3 bg-red-100 text-red-600 rounded-full shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Excluir Máquina?</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Você está prestes a remover permanentemente esta máquina do sistema. Esta ação não poderá ser desfeita.
                  </p>
                </div>
              </div>

              {/* Target machine details card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
                <span className="text-[9px] font-mono uppercase tracking-wide text-slate-400 font-bold block">
                  Máquina Selecionada
                </span>
                <p className="font-bold text-slate-900 text-sm">{machToDelete.name}</p>
                <p className="text-xs font-mono text-slate-500">Número da Máquina: {machToDelete.machineNumber}</p>
              </div>

              {/* Alert message */}
              <p className="text-[11px] text-red-600 font-bold bg-red-50 border border-red-100 p-2.5 rounded-lg leading-relaxed">
                Aviso: Se esta máquina estiver atualmente em produção, a OP correspondente voltará para a fila de espera.
              </p>

              {/* Control triggers */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setMachToDelete(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleExecuteDeleteMachine}
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm transition cursor-pointer"
                >
                  Sim, Deletar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GLOBAL MODAL: MANDATORY CONFIRMATION TO DELETE CLIENT */}
      <AnimatePresence>
        {clientToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Dark blur backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setClientToDelete(null)}
              className="absolute inset-0 bg-slate-900"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-md w-full relative z-10 text-slate-800 space-y-4"
            >
              <div className="flex items-start gap-3">
                <div className="p-3 bg-red-100 text-red-600 rounded-full shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Excluir Cliente?</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Você está prestes a remover permanentemente este cliente do sistema. Esta ação não poderá ser desfeita.
                  </p>
                </div>
              </div>

              {/* Target client details card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
                <span className="text-[9px] font-mono uppercase tracking-wide text-slate-400 font-bold block">
                  Cliente Selecionado
                </span>
                <p className="font-bold text-slate-900 text-sm">{clientToDelete.name}</p>
                {clientToDelete.companyName && (
                  <p className="text-xs font-mono text-slate-500">Razão Social: {clientToDelete.companyName}</p>
                )}
              </div>

              {/* Alert message */}
              <p className="text-[11px] text-red-600 font-bold bg-red-50 border border-red-100 p-2.5 rounded-lg leading-relaxed">
                Aviso: A exclusão do cliente também removerá todas as OPs (Ordens de Produção) associadas a ele.
              </p>

              {/* Control triggers */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setClientToDelete(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleExecuteDeleteClient}
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm transition cursor-pointer"
                >
                  Sim, Deletar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GLOBAL MODAL: WHATSAPP SHARE PREVIEW AND PHONE SETUP */}
      <AnimatePresence>
        {(whatsappModalOrder || whatsappIsSharingAll) && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Dark blur backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setWhatsappModalOrder(null);
                setWhatsappIsSharingAll(false);
              }}
              className="absolute inset-0 bg-slate-900"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-lg w-full relative z-10 text-slate-800 space-y-4"
            >
              <div className="flex items-start gap-3">
                <div className="p-3 bg-green-100 text-green-600 rounded-full shrink-0">
                  <MessageCircle className="w-6 h-6 fill-current" />
                </div>
                <div className="flex-1">
                  <h3 className="text-base font-black text-slate-900">
                    {whatsappIsSharingAll ? "Enviar Resumo Geral de Produção" : "Enviar Registro de Fabricação"}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Configure o destinatário e revise a mensagem que será enviada pelo WhatsApp.
                  </p>
                </div>
              </div>

              <form onSubmit={handleSendWhatsApp} className="space-y-4 text-xs">
                {/* Client Phone Fast Selection if sharing a single order */}
                {!whatsappIsSharingAll && whatsappModalOrder && (
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
                    <span className="text-[9px] font-mono uppercase tracking-wide text-slate-400 font-bold block">
                      Vincular Contato do Cliente
                    </span>
                    <div className="flex items-center justify-between text-slate-800 font-bold">
                      <span>{whatsappModalOrder.clientName}</span>
                      {clients.find(c => c.id === whatsappModalOrder.clientId)?.phone ? (
                        <button
                          type="button"
                          onClick={() => {
                            const cli = clients.find(c => c.id === whatsappModalOrder.clientId);
                            if (cli && cli.phone) {
                              setWhatsappPhone(cli.phone);
                            }
                          }}
                          className="text-[10px] bg-brand-green/10 text-brand-green px-2 py-1 rounded-md font-bold hover:bg-brand-green/20 transition cursor-pointer"
                        >
                          Usar Número Cadastrado
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">Nenhum telefone salvo</span>
                      )}
                    </div>
                  </div>
                )}

                {/* Phone contact dropdown quick selector */}
                {clients.filter(c => c.phone).length > 0 && (
                  <div>
                    <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                      Atalho: Selecionar de Outro Cliente Cadastrado
                    </label>
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          setWhatsappPhone(e.target.value);
                        }
                      }}
                      className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-700 font-bold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-xs"
                    >
                      <option value="">-- Escolher número de telefone rápido --</option>
                      {clients.filter(c => c.phone).map((c) => (
                        <option key={c.id} value={c.phone}>
                          {c.name} ({c.phone})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Destination Phone Input */}
                <div>
                  <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                    Número de Telefone do WhatsApp (com DDD)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      placeholder="Ex: 11987654321 ou +55 (11) 98765-4321"
                      value={whatsappPhone}
                      onChange={(e) => setWhatsappPhone(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-lg pl-10 pr-3 py-2.5 text-slate-800 font-bold focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green shadow-inner"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Se deixado em branco, o WhatsApp abrirá para você selecionar o contato manualmente.
                  </p>
                </div>

                {/* Message Customization Preview */}
                <div>
                  <label className="block text-slate-600 font-bold mb-1 font-mono uppercase tracking-wide text-[10px]">
                    Revisar Mensagem (Editável)
                  </label>
                  <textarea
                    rows={8}
                    value={whatsappCustomMessage}
                    onChange={(e) => setWhatsappCustomMessage(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 font-mono text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green leading-relaxed"
                  />
                </div>

                {/* Control triggers */}
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setWhatsappModalOrder(null);
                      setWhatsappIsSharingAll(false);
                    }}
                    className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                  >
                    Voltar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold text-white bg-brand-green hover:bg-brand-green-medium rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-current" />
                    <span>Enviar p/ WhatsApp</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
